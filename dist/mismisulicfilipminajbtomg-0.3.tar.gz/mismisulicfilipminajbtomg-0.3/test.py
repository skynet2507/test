from Mammals import Mammals
from Birds import Birds

# Create an object of Mammals class & call a method of it
myMammal = Mammals()
myMammal.print_members()

# Create an object of Birds class & call a method of it
myBird = Birds()
myBird.print_members()